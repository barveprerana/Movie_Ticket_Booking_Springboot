package com.springboot.movieticketdemo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="ticket")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode

public class Ticket {
	
	// define fields
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ticket_id")
	private int ticket_id;
	
	@Column(name="noOfSeats")
	private int noOfSeats;

	@OneToMany
	private List<Seat> seatNumber;
	
	@OneToOne
	private TicketBooking bookingRef;
	
	
	@Column(name="ticketStatus")
	private boolean ticketStatus;


	public int getTicket_id() {
		return ticket_id;
	}


	public void setTicket_id(int ticket_id) {
		this.ticket_id = ticket_id;
	}


	public int getNoOfSeats() {
		return noOfSeats;
	}


	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}


	public List<Seat> getSeatNumber() {
		return seatNumber;
	}


	public void setSeatNumber(List<Seat> seatNumber) {
		this.seatNumber = seatNumber;
	}


	public TicketBooking getBookingRef() {
		return bookingRef;
	}


	public void setBookingRef(TicketBooking bookingRef) {
		this.bookingRef = bookingRef;
	}


	public boolean isTicketStatus() {
		return ticketStatus;
	}


	public void setTicketStatus(boolean ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	
	
	
	
}	