package com.springboot.movieticketdemo.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.movieticketdemo.entity.Seat;

public interface SeatRepository extends JpaRepository<Seat, Integer> {

	// that's it ... no need to write any code LOL!
	
}

