package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Ticket;
import com.springboot.movieticketdemo.service.TicketService;

@RestController
@RequestMapping("/api")
public class TicketRestController {

	private TicketService ticketService;
	
	@Autowired
	public TicketRestController(TicketService theTicketService) {
		ticketService = theTicketService;
	}
	
	@GetMapping("/tickets")
	public List<Ticket> findAll() {
		return ticketService.findAll();
	}
	
	@GetMapping("/tickets/{ticketID}")
	public Ticket getTicket(@PathVariable int ticketID) {
		
		Ticket theTicket = ticketService.findById(ticketID);
		
		if (theTicket == null) {
			throw new RuntimeException("Ticket id not found - " + ticketID);
		}
		
		return theTicket;
	}
	
	@PostMapping("/tickets")
	public Ticket addTicket(@RequestBody Ticket theTicket) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theTicket.setTicket_id(0);
		
		ticketService.save(theTicket);
		
		return theTicket;
	}
	
	
	@PutMapping("/tickets")
	public Ticket updateTicket(@RequestBody Ticket theTicket) {
		
		ticketService.save(theTicket);
		
		return theTicket;
	}
	

	@DeleteMapping("/tickets/{ticketId}")
	public String deleteTicket(@PathVariable int ticketId) {
		
		Ticket tempTicket = ticketService.findById(ticketId);
		
		// throw exception if null
		
		if (tempTicket== null) {
			throw new RuntimeException("Ticket id not found - " +ticketId);
		}
		ticketService.deleteById(ticketId);
		
		return "Deleted Ticket id - " +ticketId;
	}
	
}
