package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Screen;


@Service
public interface ScreenService {
	public List<Screen> findAll();
	
	public Screen findById(int theId);
	
	public void save(Screen theScreen);
	
	public void deleteById(int theId);
}