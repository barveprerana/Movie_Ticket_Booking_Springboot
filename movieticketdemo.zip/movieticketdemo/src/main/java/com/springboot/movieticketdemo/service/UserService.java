package com.springboot.movieticketdemo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.User;

@Service
public interface UserService {
	public List<User> findAll();
	
	public User findById(int theId);
	
	public void save(User theUser);
	
	public void deleteById(int theId);
}
