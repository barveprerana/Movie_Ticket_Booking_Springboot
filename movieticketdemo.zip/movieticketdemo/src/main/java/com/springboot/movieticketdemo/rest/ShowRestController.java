package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Movies;
import com.springboot.movieticketdemo.entity.Show;
import com.springboot.movieticketdemo.service.ShowService;

@RestController
@RequestMapping("/api")
public class ShowRestController {

	private ShowService showService;
	
	@Autowired
	public ShowRestController(ShowService theShowServicee) {
		showService = theShowServicee;
	}
	
	@GetMapping("/shows")
	public List<Show> findAll() {
		return showService.findAll();
	}
	
	@GetMapping("/shows/{showsID}")
	public Show getUser(@PathVariable int showID) {
		
		Show theShow = showService.findById(showID);
		
		if (theShow == null) {
			throw new RuntimeException("Show id not found - " + showID);
		}
		
		return theShow;
	}
	
	@PostMapping("/shows")
	public Show addShow(@RequestBody Show theShow) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theShow.setShowId(0);
		
		showService.save(theShow);
		
		return theShow;
	}
	
	
	
	
	@PutMapping("/shows")
	public Show updateShow(@RequestBody Show theShow) {
		
		showService.save(theShow);
		
		return theShow;
	}
	

	@DeleteMapping("/shows/{showId}")
	public String deleteShow(@PathVariable int showId) {
		
		Show tempShow = showService.findById(showId);
		
		// throw exception if null
		
		if (tempShow == null) {
			throw new RuntimeException("Show id not found - " + showId);
		}
		
		showService.deleteById(showId);
		
		return "Deleted Show id - " +showId;
	}
	
}