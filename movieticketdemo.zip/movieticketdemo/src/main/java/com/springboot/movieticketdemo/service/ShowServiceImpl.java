package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.ShowRepository;
import com.springboot.movieticketdemo.entity.Show;



@Service
public class ShowServiceImpl implements ShowService {

	private ShowRepository showRepository;
	
	@Autowired
	public ShowServiceImpl(ShowRepository theShowRepository) {
		showRepository = theShowRepository;
	}
	
	@Override
	public List<Show> findAll() {
		return showRepository.findAll();
	}

	@Override
	public Show findById(int theId) {
		Optional<Show> result = showRepository.findById(theId);
		
		Show theShow = null;
		
		if (result.isPresent()) {
			theShow = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Show id - " + theId);
		}
		
		return theShow;
	}

	@Override
	public void save(Show theShow) {
		showRepository.save(theShow);
	}

	@Override
	public void deleteById(int theId) {
		showRepository.deleteById(theId);
	}
}