package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.TicketBooking;


@Service
public interface TicketBookingService {
	public List<TicketBooking> findAll();
	
	public TicketBooking findById(int theId);
	
	public void save(TicketBooking theTicketBooking);
	
	public void deleteById(int theId);
}