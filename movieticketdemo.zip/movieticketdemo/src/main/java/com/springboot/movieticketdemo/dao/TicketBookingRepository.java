package com.springboot.movieticketdemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.movieticketdemo.entity.TicketBooking;

public interface TicketBookingRepository extends JpaRepository<TicketBooking, Integer> {

	// that's it ... no need to write any code LOL!
	
}
