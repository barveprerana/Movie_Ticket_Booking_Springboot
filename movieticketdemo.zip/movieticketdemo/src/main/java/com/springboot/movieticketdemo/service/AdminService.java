package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Admin;


@Service
public interface AdminService {
	public List<Admin> findAll();
	
	public Admin findById(int theId);
	
	public void save(Admin theAdmin);
	
	public void deleteById(int theId);
}
