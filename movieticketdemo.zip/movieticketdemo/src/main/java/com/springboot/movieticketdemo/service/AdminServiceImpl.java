package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.AdminRepository;
import com.springboot.movieticketdemo.dao.ShowRepository;
import com.springboot.movieticketdemo.entity.Admin;
import com.springboot.movieticketdemo.entity.Show;



@Service
public class AdminServiceImpl implements AdminService {

	private AdminRepository adminRepository;
	
	@Autowired
	public AdminServiceImpl(AdminRepository theAdminRepository) {
		adminRepository = theAdminRepository;
	}
	
	@Override
	public List<Admin> findAll() {
		return adminRepository.findAll();
	}

	@Override
	public Admin findById(int theId) {
		Optional<Admin> result = adminRepository.findById(theId);
		
		Admin theAdmin = null;
		
		if (result.isPresent()) {
			theAdmin = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Admin id - " + theId);
		}
		
		return theAdmin;
	}

	@Override
	public void save(Admin theAdmin) {
		adminRepository.save(theAdmin);
	}

	@Override
	public void deleteById(int theId) {
		adminRepository.deleteById(theId);
	}
}