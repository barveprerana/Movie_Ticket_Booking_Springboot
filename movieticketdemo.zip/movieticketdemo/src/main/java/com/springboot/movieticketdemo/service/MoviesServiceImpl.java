package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.MoviesRepository;
import com.springboot.movieticketdemo.entity.Movies;
import com.springboot.movieticketdemo.entity.Show;



@Service
public class MoviesServiceImpl implements MoviesService {

	private MoviesRepository moviesRepository;
	
	@Autowired
	public MoviesServiceImpl(MoviesRepository theMoviesRepository) {
		moviesRepository = theMoviesRepository;
	}
	
	@Override
	public List<Movies> findAll() {
		return moviesRepository.findAll();
	}

	public Movies findById(int theId) {
		Optional<Movies> result = moviesRepository.findById(theId);
		
		Movies theMovies = null;
		
		if (result.isPresent()) {
			theMovies = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Movies id - " + theId);
		}
		
		return theMovies;
	}


	@Override
	public void save(Movies theMovies) {
		moviesRepository.save(theMovies);
	}

	@Override
	public void deleteById(int theId) {
		moviesRepository.deleteById(theId);
	}
}

