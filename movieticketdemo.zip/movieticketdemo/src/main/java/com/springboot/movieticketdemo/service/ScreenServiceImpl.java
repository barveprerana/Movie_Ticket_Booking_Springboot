package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.ScreenRepository;
import com.springboot.movieticketdemo.entity.Screen;



@Service
public class ScreenServiceImpl implements ScreenService {

	private ScreenRepository screenRepository;
	
	@Autowired
	public ScreenServiceImpl(ScreenRepository theScreenRepository) {
		screenRepository = theScreenRepository;
	}
	
	@Override
	public List<Screen> findAll() {
		return screenRepository.findAll();
	}

	@Override
	public Screen findById(int theId) {
		Optional<Screen> result = screenRepository.findById(theId);
		
		Screen theScreen = null;
		
		if (result.isPresent()) {
			theScreen = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Screen id - " + theId);
		}
		
		return theScreen;
	}

	@Override
	public void save(Screen theScreen) {
		screenRepository.save(theScreen);
	}

	@Override
	public void deleteById(int theId) {
		screenRepository.deleteById(theId);
	}


}

