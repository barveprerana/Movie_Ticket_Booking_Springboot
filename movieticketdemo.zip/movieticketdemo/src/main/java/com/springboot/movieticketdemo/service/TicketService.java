package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Ticket;

@Service
public interface TicketService {
	public List<Ticket> findAll();
	
	public Ticket findById(int theId);
	
	public void save(Ticket theTicket);
	
	public void deleteById(int theId);
}
