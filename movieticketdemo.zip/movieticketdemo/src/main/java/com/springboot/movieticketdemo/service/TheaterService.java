package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Theater;


@Service
public interface TheaterService {
	public List<Theater> findAll();
	
	public Theater findById(int theId);
	
	public void save(Theater theTheater);
	
	public void deleteById(int theId);
}