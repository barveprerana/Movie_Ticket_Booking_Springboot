package com.springboot.movieticketdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(info=@Info(title="Movie Ticket Booking Application",version="1.0",description="An API used for Online Movie Ticket Booking Implementation."))
public class MovieticketdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieticketdemoApplication.class, args);
	}

}
