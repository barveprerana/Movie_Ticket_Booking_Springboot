package com.springboot.movieticketdemo.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="ticketbooking")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode

public class TicketBooking {
	
	// define fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ticketId")
	private int ticketId;
	
	@Column(name="showId")
	private int showId;
	
	@Column(name="bookingDate")
	private LocalDateTime bookingDate;
	
	@Column(name="transactionId")
	private int transactionId ;
	
	@Column(name="transactionModel")
	private String transactionModel; 
	
	@Column(name="transactionStatus")
	private String transactionStatus; 
	
	
	@Column(name="totalCost")
	private double totalCost;
	
	@OneToOne
	private Customer customer;

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public LocalDateTime getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionModel() {
		return transactionModel;
	}

	public void setTransactionModel(String transactionModel) {
		this.transactionModel = transactionModel;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	
	

}

	

