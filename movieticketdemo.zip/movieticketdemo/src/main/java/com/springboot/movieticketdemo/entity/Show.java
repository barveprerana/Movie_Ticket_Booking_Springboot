package com.springboot.movieticketdemo.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="show")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode

public class Show {
	
	// define fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="showId")
	private int showId;
	
	@Column(name="showStartTime")
	private LocalDateTime showStartTime;
	
	@Column(name="showEndTime")
	private LocalDateTime showEndTime;
	
	@Column(name="showName")
	private String showName; 
	
	@OneToOne
	private Movies movies;
	
	/*@Column(name="screenid")
	private double screenid;
	
	@Column(name="theaterid")
	private double theaterid;*/

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowStartTime() {
		return showStartTime;
	}

	public void setShowStartTime(LocalDateTime showStartTime) {
		this.showStartTime = showStartTime;
	}

	public LocalDateTime getShowEndTime() {
		return showEndTime;
	}

	public void setShowEndTime(LocalDateTime showEndTime) {
		this.showEndTime = showEndTime;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public Movies getMovies() {
		return movies;
	}

	public void setMovies(Movies movies) {
		this.movies = movies;
	}

	/*public double getScreenid() {
		return screenid;
	}

	public void setScreenid(double screenid) {
		this.screenid = screenid;
	}

	public double getTheaterid() {
		return theaterid;
	}

	public void setTheaterid(double theaterid) {
		this.theaterid = theaterid;
	}*/

	
}	