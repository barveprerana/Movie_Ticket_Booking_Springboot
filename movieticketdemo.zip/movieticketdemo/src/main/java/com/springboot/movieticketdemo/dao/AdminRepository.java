package com.springboot.movieticketdemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.movieticketdemo.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {

	// that's it ... no need to write any code LOL!
	
}