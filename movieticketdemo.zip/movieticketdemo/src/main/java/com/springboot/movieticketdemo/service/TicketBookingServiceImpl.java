package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.TicketBookingRepository;
import com.springboot.movieticketdemo.entity.TicketBooking;



@Service
public class TicketBookingServiceImpl implements TicketBookingService {

	private TicketBookingRepository ticketBookingRepository;
	
	@Autowired
	public TicketBookingServiceImpl(TicketBookingRepository theTicketBookingRepository) {
		ticketBookingRepository = theTicketBookingRepository;
	}
	
	@Override
	public List<TicketBooking> findAll() {
		return ticketBookingRepository.findAll();
	}

	@Override
	public TicketBooking findById(int theId) {
		Optional<TicketBooking> result = ticketBookingRepository.findById(theId);
		
		TicketBooking theTicketBooking = null;
		
		if (result.isPresent()) {
			theTicketBooking = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find TicketBooking id - " + theId);
		}
		
		return theTicketBooking;
	}

	@Override
	public void save(TicketBooking theTicketBooking) {
		ticketBookingRepository.save(theTicketBooking);
	}

	@Override
	public void deleteById(int theId) {
		ticketBookingRepository.deleteById(theId);
	}

}