package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Admin;
import com.springboot.movieticketdemo.service.AdminService;

@RestController
@RequestMapping("/api")
public class AdminRestController {

	private AdminService AdminService;
	
	@Autowired
	public AdminRestController(AdminService theAdminService) {
		AdminService = theAdminService;
	}
	
	@GetMapping("/admins")
	public List<Admin> findAll() {
		return AdminService.findAll();
	}
	
	@GetMapping("/admins/{adminId}")
	public Admin getAdmin(@PathVariable int adminID) {
		
		Admin theAdmin = AdminService.findById(adminID);
		
		if (theAdmin == null) {
			throw new RuntimeException("Admin id not found - " + adminID);
		}
		
		return theAdmin;
	}
	
	@PostMapping("/admins")
	public Admin addAdmin(@RequestBody Admin theAdmin) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theAdmin.setAdmin_id(0);
		
		AdminService.save(theAdmin);
		
		return theAdmin;
	}
	
	
	@PutMapping("/admins")
	public Admin updateAdmin(@RequestBody Admin theAdmin) {
		
		AdminService.save(theAdmin);
		
		return theAdmin;
	}
	

	@DeleteMapping("/admins/{adminId}")
	public String deleteAdmin(@PathVariable int adminID) {
		
		Admin tempAdmin = AdminService.findById(adminID);
		
		// throw exception if null
		
		if (tempAdmin == null) {
			throw new RuntimeException("Admin id not found - " + adminID);
		}
		
		AdminService.deleteById(adminID);
		
		return "Deleted Admin id - " + adminID;
	}
	
}
