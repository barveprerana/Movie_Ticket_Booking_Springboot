package com.springboot.movieticketdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.TheaterRepository;
import com.springboot.movieticketdemo.entity.Theater;



@Service
public class TheaterServiceImpl implements TheaterService {

	private TheaterRepository theaterRepository;
	
	@Autowired
	public TheaterServiceImpl(TheaterRepository theTheaterRepository) {
		theaterRepository = theTheaterRepository;
	}
	
	@Override
	public List<Theater> findAll() {
		return theaterRepository.findAll();
	}

	@Override
	public Theater findById(int theId) {
		Optional<Theater> result = theaterRepository.findById(theId);
		
		Theater theTheater = null;
		
		if (result.isPresent()) {
			theTheater = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Theater id - " + theId);
		}
		
		return theTheater;
	}

	@Override
	public void save(Theater theTheater) {
		theaterRepository.save(theTheater);
	}

	@Override
	public void deleteById(int theId) {
		theaterRepository.deleteById(theId);
	}



}

