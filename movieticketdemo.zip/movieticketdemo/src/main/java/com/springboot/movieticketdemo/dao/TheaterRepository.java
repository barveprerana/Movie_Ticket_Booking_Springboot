package com.springboot.movieticketdemo.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.movieticketdemo.entity.Theater;

public interface TheaterRepository extends JpaRepository<Theater, Integer> {

	// that's it ... no need to write any code LOL!
	
}