package com.springboot.movieticketdemo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Entity
@Table(name="theater")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode

public class Theater {
	
	// define fields
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="theaterName")
	private String theaterName;
	
	@Column(name="theaterCity")
	private String theaterCity;
	
	@OneToMany
	private List<Movies> listOfMovies;
	
	@OneToMany
	private List<Screen> listOfScreens;

	@Column(name="managername")
	private String managername ;
	
	@Column(name="managercontact")
	private String managercontact;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getTheaterCity() {
		return theaterCity;
	}

	public void setTheaterCity(String theaterCity) {
		this.theaterCity = theaterCity;
	}

	public List<Movies> getListOfMovies() {
		return listOfMovies;
	}

	public void setListOfMovies(List<Movies> listOfMovies) {
		this.listOfMovies = listOfMovies;
	}

	public List<Screen> getListOfScreens() {
		return listOfScreens;
	}

	public void setListOfScreens(List<Screen> listOfScreens) {
		this.listOfScreens = listOfScreens;
	}

	public String getManagername() {
		return managername;
	}

	public void setManagername(String managername) {
		this.managername = managername;
	}

	public String getManagercontact() {
		return managercontact;
	}

	public void setManagercontact(String managercontact) {
		this.managercontact = managercontact;
	}

	
	
}