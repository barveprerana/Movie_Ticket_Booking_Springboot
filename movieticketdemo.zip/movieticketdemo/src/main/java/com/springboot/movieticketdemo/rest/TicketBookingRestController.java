package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.TicketBooking;
import com.springboot.movieticketdemo.service.TicketBookingService;

@RestController
@RequestMapping("/api")
public class TicketBookingRestController {

	private TicketBookingService ticketBookingService;
	
	@Autowired
	public TicketBookingRestController(TicketBookingService theTicketBookingServicee) {
		ticketBookingService = theTicketBookingServicee;
	}
	
	@GetMapping("/bookings")
	public List<TicketBooking> findAll() {
		return ticketBookingService.findAll();
	}
	
	@GetMapping("/bookings/{bookingID}")
	public TicketBooking getTicketBooking(@PathVariable int ticketBookingID) {
		
		TicketBooking theTicketBooking = ticketBookingService.findById(ticketBookingID);
		
		if (theTicketBooking == null) {
			throw new RuntimeException("TicketBooking id not found - " + ticketBookingID);
		}
		
		return theTicketBooking;
	}
	
	@PostMapping("/bookings")
	public TicketBooking addTicketBooking(@RequestBody TicketBooking theTicketBooking) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theTicketBooking.setTicketId(0);
		
		ticketBookingService.save(theTicketBooking);
		
		return theTicketBooking;
	}
	
	
	@PutMapping("/bookings")
	public TicketBooking updateTicketBooking(@RequestBody TicketBooking theTicketBooking) {
		
		ticketBookingService.save(theTicketBooking);
		
		return theTicketBooking;
	}
	

	@DeleteMapping("/bookings/{bookingId}")
	public String deleteTicketBooking(@PathVariable int ticketBookingId) {
		
		TicketBooking tempTicketBooking = ticketBookingService.findById(ticketBookingId);
		
		// throw exception if null
		
		if (tempTicketBooking == null) {
			throw new RuntimeException("TicketBooking id not found - " + ticketBookingId);
		}
		
		ticketBookingService.deleteById(ticketBookingId);
		
		return "Deleted TicketBooking id - " +ticketBookingId;
	}
	
}