package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Theater;
import com.springboot.movieticketdemo.service.TheaterService;

@RestController
@RequestMapping("/api")
public class TheaterRestController {

	private TheaterService theaterService;
	
	@Autowired
	public TheaterRestController(TheaterService theTheaterServicee) {
		theaterService = theTheaterServicee;
	}
	
	@GetMapping("/theaters")
	public List<Theater> findAll() {
		return theaterService.findAll();
	}
	
	@GetMapping("/theaters/{theaterID}")
	public Theater getTheater(@PathVariable int theaterID) {
		
		Theater theTheater = theaterService.findById(theaterID);
		
		if (theTheater == null) {
			throw new RuntimeException("Theater id not found - " + theaterID);
		}
		
		return theTheater;
	}
	
	@PostMapping("/theaters")
	public Theater addTheater(@RequestBody Theater theTheater) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theTheater.setId(0);
		
		theaterService.save(theTheater);
		
		return theTheater;
	}
	
	
	@PutMapping("/theaters")
	public Theater updateTheater(@RequestBody Theater theTheater) {
		
		theaterService.save(theTheater);
		
		return theTheater;
	}
	

	@DeleteMapping("/theaters/{theaterId}")
	public String deleteTheater(@PathVariable int theaterId) {
		
		Theater tempTheater = theaterService.findById(theaterId);
		
		// throw exception if null
		
		if (tempTheater == null) {
			throw new RuntimeException("Theater id not found - " + theaterId);
		}
		
		theaterService.deleteById(theaterId);
		
		return "Deleted Theater id - " +theaterId;
	}
	
}