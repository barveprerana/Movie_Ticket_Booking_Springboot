package com.springboot.movieticketdemo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Seat;


@Service
public interface SeatService {
	public List<Seat> findAll();
	
	public Seat findById(int theId);
	
	public void save(Seat theSeat);
	
	public void deleteById(int theId);
}