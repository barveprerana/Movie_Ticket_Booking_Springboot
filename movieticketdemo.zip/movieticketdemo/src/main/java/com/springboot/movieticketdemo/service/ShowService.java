package com.springboot.movieticketdemo.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Show;


@Service
public interface ShowService {
	public List<Show> findAll();
	
	public Show findById(int theId);
	
	public void save(Show theShow);
	
	public void deleteById(int theId);
}