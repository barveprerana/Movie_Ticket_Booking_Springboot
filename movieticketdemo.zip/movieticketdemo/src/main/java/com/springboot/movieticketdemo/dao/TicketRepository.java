package com.springboot.movieticketdemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.movieticketdemo.entity.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Integer> {

	// that's it ... no need to write any code LOL!
	
}

