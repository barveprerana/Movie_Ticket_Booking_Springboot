package com.springboot.movieticketdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.entity.Movies;


@Service
public interface MoviesService {
	public List<Movies> findAll();
	
	public Movies findById(int theId);
	
	public void save(Movies theMovies);
	
	public void deleteById(int theId);
}