package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Movies;
import com.springboot.movieticketdemo.service.MoviesService;

@RestController
@RequestMapping("/api")
public class MoviesRestController {

	private MoviesService moviesService;
	
	@Autowired
	public MoviesRestController(MoviesService theMoviesServicee) {
		moviesService = theMoviesServicee;
	}
	
	@GetMapping("/movies")
	public List<Movies> findAll() {
		return moviesService.findAll();
	}
	
	@GetMapping("/movies/{moviesID}")
	public Movies getMovies(@PathVariable int moviesID) {
		
		Movies theMovies = moviesService.findById(moviesID);
		
		if (theMovies == null) {
			throw new RuntimeException("Movies id not found - " + moviesID);
		}
		
		return theMovies;
	}
	
	@PostMapping("/movies")
	public Movies addMovies(@RequestBody Movies theMovies) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theMovies.setMovieid(0);
		
		moviesService.save(theMovies);
		
		return theMovies;
	}
	
	
	@PutMapping("/movies")
	public Movies updateMovies(@RequestBody Movies theMovies) {
		
		moviesService.save(theMovies);
		
		return theMovies;
	}
	

	@DeleteMapping("/movies/{moviesId}")
	public String deleteMovies(@PathVariable int moviesId) {
		
		Movies tempMovies = moviesService.findById(moviesId);
		
		// throw exception if null
		
		if (tempMovies == null) {
			throw new RuntimeException("Movies id not found - " + moviesId);
		}
		
		moviesService.deleteById(moviesId);
		
		return "Deleted Movies id - " +moviesId;
	}
	
}