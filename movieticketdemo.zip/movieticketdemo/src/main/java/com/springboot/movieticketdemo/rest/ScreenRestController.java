package com.springboot.movieticketdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.movieticketdemo.entity.Screen;
import com.springboot.movieticketdemo.service.ScreenService;

@RestController
@RequestMapping("/api")
public class ScreenRestController {

	private ScreenService screenService;
	
	@Autowired
	public ScreenRestController(ScreenService theScreenServicee) {
		screenService = theScreenServicee;
	}
	
	@GetMapping("/screens")
	public List<Screen> findAll() {
		return screenService.findAll();
	}
	
	@GetMapping("/screens/{screenID}")
	public Screen getScreen(@PathVariable int screenID) {
		
		Screen theScreen = screenService.findById(screenID);
		
		if (theScreen == null) {
			throw new RuntimeException("Screen id not found - " + screenID);
		}
		
		return theScreen;
	}
	
	@PostMapping("/screens")
	public Screen addScreen(@RequestBody Screen theScreen) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		theScreen.setScreenId(0);
		
		screenService.save(theScreen);
		
		return theScreen;
	}
	
	
	@PutMapping("/screens")
	public Screen updateScreen(@RequestBody Screen theScreen) {
		
		screenService.save(theScreen);
		
		return theScreen;
	}
	

	@DeleteMapping("/screens/{screenId}")
	public String deleteScreen(@PathVariable int screenId) {
		
		Screen tempScreen = screenService.findById(screenId);
		
		// throw exception if null
		
		if (tempScreen == null) {
			throw new RuntimeException("Screen id not found - " + screenId);
		}
		
		screenService.deleteById(screenId);
		
		return "Deleted Screen id - " +screenId;
	}
	
}