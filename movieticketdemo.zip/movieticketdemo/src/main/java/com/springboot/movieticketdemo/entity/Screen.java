package com.springboot.movieticketdemo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="Screen")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Screen {
	// define fields
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="screenId")
		private int screenId;
		
		//@OneToOne
		//private int theaterId;
		
		@Column(name="screenName")
		private String screenName;
		
		@OneToMany
		private List<Show> showList;
		
		@Column(name="rows")
		private int rows;
		
		@Column(name="columns")
		private int columns;

		public int getScreenId() {
			return screenId;
		}

		public void setScreenId(int screenId) {
			this.screenId = screenId;
		}

		/*public int getTheaterId() {
			return theaterId;
		}

		public void setTheaterId(int theaterId) {
			this.theaterId = theaterId;
		}*/

		public String getScreenName() {
			return screenName;
		}

		public void setScreenName(String screenName) {
			this.screenName = screenName;
		}

		public List<Show> getShowList() {
			return showList;
		}

		public void setShowList(List<Show> showList) {
			this.showList = showList;
		}

		public int getRows() {
			return rows;
		}

		public void setRows(int rows) {
			this.rows = rows;
		}

		public int getColumns() {
			return columns;
		}

		public void setColumns(int columns) {
			this.columns = columns;
		}

		
		
		

		

}