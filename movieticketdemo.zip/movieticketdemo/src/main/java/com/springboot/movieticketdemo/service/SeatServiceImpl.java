package com.springboot.movieticketdemo.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.movieticketdemo.dao.SeatRepository;
import com.springboot.movieticketdemo.entity.Seat;
import com.springboot.movieticketdemo.entity.Show;



@Service
public class SeatServiceImpl implements SeatService {

	private SeatRepository seatRepository;
	
	@Autowired
	public SeatServiceImpl(SeatRepository theSeatRepository) {
		seatRepository = theSeatRepository;
	}
	
	@Override
	public List<Seat> findAll() {
		return seatRepository.findAll();
	}

	public Seat findById(int theId) {
		Optional<Seat> result = seatRepository.findById(theId);
		
		Seat theSeat = null;
		
		if (result.isPresent()) {
			theSeat = result.get();
		}
		else {
			// we didn't find the Bill
			throw new RuntimeException("Did not find Seat id - " + theId);
		}
		
		return theSeat;
	}


	@Override
	public void save(Seat theSeat) {
		seatRepository.save(theSeat);
	}

	@Override
	public void deleteById(int theId) {
		seatRepository.deleteById(theId);
	}
}

