package com.springboot.movieticketdemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="movie")
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode

public class Movies {
	
	// define fields
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="movieid")
	private int movieid;
	
	@Column(name="movieName")
	private String movieName;
	
	@Column(name="movieCenter")
	private String movieCenter;
	
	@Column(name="movieHours")
	private String movieHours;
	
	@Column(name="language")
	private String language ;

	@Column(name="description")
	private String description ;

	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getMovieCenter() {
		return movieCenter;
	}

	public void setMovieCenter(String movieCenter) {
		this.movieCenter = movieCenter;
	}

	public String getMovieHours() {
		return movieHours;
	}

	public void setMovieHours(String movieHours) {
		this.movieHours = movieHours;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}

	