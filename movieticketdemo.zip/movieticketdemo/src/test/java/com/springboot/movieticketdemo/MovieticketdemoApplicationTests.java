package com.springboot.movieticketdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieticketdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
